/*public class Main {
    public static void main(String[] args) {
        int wynik = 0;
        try{
            wynik = dzielenie(15, 0);
            return;
        } catch (ArithmeticException e) {
            System.out.println("Dzielenie przez 0");
            wynik = 0;
            return;
        }finally {
            System.out.println(wynik);
        }
    }

    public static int dzielenie(int a, int b){
        return a/b;
    }
}*/

/*
public class Main {
    public static void main(String[] args) {
        //delegacje
        KierownikWycieczki kierownik = new KierownikWycieczki(new Koncert());
        kierownik.zalatwBilet();
        kierownik = new KierownikWycieczki(new Pociag());
        kierownik.zalatwBilet();
        kierownik = new KierownikWycieczki(new Kino());
        kierownik.zalatwBilet();
    }
}*/

import zad1.Biuro;
import zad1.StandardowyPrinter;
import zad2.BenzynowySilnik;
import zad2.Samochod;
import zad3.Email;
import zad3.Uzytkownik;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Zad 1
        //Wykonaj poniższe czynności:
            //Stwórz interfejs zad1.Printer z metodą drukuj(String tekst).
            //Utwórz klasę zad1.StandardowyPrinter, która implementuje zad1.Printer i wypisuje tekst na konsolę.
            //Utwórz klasę zad1.Biuro, która posiada prywatne pole typu zad1.Printer. W konstruktorze zad1.Biuro przyjmij zad1.Printer jako argument i przypisz go do pola. Dodaj metodę drukujDokument(String tekst), która będzie delegować zadanie drukowania do obiektu klasy zad1.Printer.
        StandardowyPrinter standardowyPrinter = new StandardowyPrinter();
        Biuro biuro = new Biuro(standardowyPrinter);
//        biuro.drukujDokument("To jest ważny dokument");
//        standardowyPrinter.drukuj("To jest inny dokument");

        //Zad 2
        //Wykonaj poniższe czynności:
            //Stwórz interfejs zad2.Silnik z metodami uruchom() i zatrzymaj().
            //Utwórz klasę zad2.BenzynowySilnik, która implementuje zad2.Silnik i symuluje działanie silnika na benzynę.
            //Utwórz klasę Samochód, która posiada prywatne pole typu zad2.Silnik. W konstruktorze przyjmij zad2.Silnik jako argument. Dodaj metody start() i stop(), które będą delegować odpowiednio zadanie uruchomienia i zatrzymania silnika do obiektu klasy zad2.Silnik.
//        BenzynowySilnik benzynowySilnik = new BenzynowySilnik();
//        Samochod samochod = new Samochod(benzynowySilnik);
//        samochod.start();
//        samochod.stop();

        //Zad 3
        //Wykonaj poniższe czynności:
            //Stwórz interfejs zad3.Powiadomienie z metodą wyślij(String wiadomość).
            //Utwórz klasę zad3.Email, która implementuje zad3.Powiadomienie i symuluje wysyłanie wiadomości e-mail.
            //Utwórz klasę Użytkownik, która posiada prywatne pole typu zad3.Powiadomienie. W konstruktorze przyjmij zad3.Powiadomienie jako argument. Dodaj metodę powiadomOModernizacji(String informacja), która będzie delegować zadanie wysyłania powiadomienia do obiektu klasy zad3.Powiadomienie.
        Email email = new Email();
        Uzytkownik uzytkownik = new Uzytkownik(email);
//        uzytkownik.powiadomOModernizacji("Modernizacja");

        //Zad 4
        //Napisz program, który definiuje metodę checkAge(int age). Metoda ta powinna rzucić wyjątek IllegalArgumentException z odpowiednim komunikatem, jeśli podany wiek jest mniejszy niż 18. W głównej metodzie programu (main) wywołaj checkAge z różnymi wartościami i obsłuż wyjątek, wyświetlając stosowny komunikat dla użytkownika.
        /*try {
            checkAge(25);
            checkAge(16);
            checkAge(30);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }*/

        //Zad 5
        //Napisz program, który prosi użytkownika o wpisanie dwóch liczb, a następnie dzieli pierwszą liczbę przez drugą. Program powinien obsługiwać dwa rodzaje wyjątków: ArithmeticException w przypadku dzielenia przez zero i InputMismatchException, gdy użytkownik wprowadzi coś innego niż liczby. W obu przypadkach należy wyświetlić stosowny komunikat błędu i poprosić użytkownika o ponowne wprowadzenie danych. Wykorzystaj typ int.
        Scanner scanner = new Scanner(System.in);

        /*int wynik = 0;
        try{
            System.out.println("Podaj liczbe 1: ");
            int a = scanner.nextInt();
            System.out.println("Podaj liczbe 2: ");
            int b = scanner.nextInt();
            wynik = a/b;
            System.out.println("Wynik: " + wynik);
        }catch (ArithmeticException e){
            System.out.println("Error: Dzielenie przez 0");
        }catch (InputMismatchException e){
            System.out.println("Error: Wprowadzono nieporawna wartosc");
        }*/

        //Zad 6
        //Zaprojektuj i zaimplementuj klasę wyjątku NiepoprawnyFormatDanychException, która będzie rozszerzać klasę Exception. Następnie napisz metodę sprawdzFormatDanych(String dane), która rzuci wyjątek NiepoprawnyFormatDanychException, jeśli podany ciąg znaków nie odpowiada określonemu wzorcowi (np. nie jest adresem e-mail). W metodzie main przetestuj działanie tej metody, obsługując wyjątek i informując użytkownika o błędzie.
        try {
            sprawdzFormatDanych("niepoprawnyAdresEmail");
            System.out.println("Format danych jest poprawny");
        } catch (NiepoprawnyFormatDanychException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    //Zad 4
    public static void checkAge(int age) {
        if (age < 18) {
            throw new IllegalArgumentException("Wiek nie moze byc mniejszy niz 18");
        } else {
            System.out.println("Wiek zaakceptowany");
        }
    }

    //Zad 6
    public static void sprawdzFormatDanych(String dane) throws  NiepoprawnyFormatDanychException {
        if (!dane.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")) {
            throw new NiepoprawnyFormatDanychException("Niepoprawny format danych");
        }
    }
}