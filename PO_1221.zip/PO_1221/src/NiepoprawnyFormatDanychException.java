public class NiepoprawnyFormatDanychException extends Exception{
    public NiepoprawnyFormatDanychException(String s){
        super(s);
    }
}
