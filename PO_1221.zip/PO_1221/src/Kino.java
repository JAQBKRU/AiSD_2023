public class Kino implements Biletomat{
    @Override
    public void wystawBilet() {
        System.out.println("Wystawiono bilet do kina");
    }
}
