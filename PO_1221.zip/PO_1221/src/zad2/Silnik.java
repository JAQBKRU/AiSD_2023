package zad2;

public interface Silnik{
    public void uruchom();
    public void zatrzymaj();
}
