package zad2;

public class main {
    public static void main(String[] args) {
        BenzynowySilnik benzynowySilnik = new BenzynowySilnik();
        Samochod samochod = new Samochod(benzynowySilnik);
        samochod.start();
        samochod.stop();
    }
}
