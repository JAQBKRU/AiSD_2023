package zad1;

public interface Printer {
    void drukuj(String tekst);
}
