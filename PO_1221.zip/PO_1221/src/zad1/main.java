package zad1;

public class main {
    public static void main(String[] args) {
        StandardowyPrinter standardowyPrinter = new StandardowyPrinter();
        Biuro biuro = new Biuro(standardowyPrinter);
        biuro.drukujDokument("To jest ważny dokument");
        standardowyPrinter.drukuj("To jest inny dokument");
    }
}
