package zad3;

public interface Powiadomienie {
    void wyślij(String wiadomosc);
}
