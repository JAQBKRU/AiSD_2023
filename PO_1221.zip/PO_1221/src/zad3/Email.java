package zad3;

public class Email implements Powiadomienie{
    @Override
    public void wyślij(String wiadomosc) {
        System.out.println(wiadomosc);
    }
}
