//delegacje
public interface Biletomat {
    void wystawBilet();
}
